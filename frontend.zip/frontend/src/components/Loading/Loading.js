import React from 'react';

const Loading = () => {
  return (
    <div>
      <h1>Loading please wait......</h1>
    </div>
  );
};

export default Loading;